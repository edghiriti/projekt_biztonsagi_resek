﻿namespace LangTogether.Services
{
    public class UserContextService : IUserContextService
    {
        public string UserId { get; set; }
    }
}
