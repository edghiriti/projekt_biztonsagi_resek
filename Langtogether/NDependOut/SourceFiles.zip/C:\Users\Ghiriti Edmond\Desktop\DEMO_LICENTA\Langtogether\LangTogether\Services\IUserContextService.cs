﻿namespace LangTogether.Services
{
    public interface IUserContextService
    {
        string UserId { get; set; }
    }
}
